package com.example.rfida;

public class TasksC {
    private String taskName;


    public TasksC() {
    }

    public TasksC(String taskName, String taskDate, String card) {
        this.taskName = taskName;

    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

}
