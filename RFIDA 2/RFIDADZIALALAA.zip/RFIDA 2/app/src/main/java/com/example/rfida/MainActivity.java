package com.example.rfida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;


public class MainActivity extends AppCompatActivity {
    private String taskName, taskDuration, taskDescription;
    private Button viewTasksBtn;
    // creating a variable
    // for firebasefirestore.
    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = FirebaseFirestore.getInstance();

        // initializing our edittext and buttons
        viewTasksBtn = findViewById(R.id.idBtnViewTasks);

        // adding onclick listener to view data in new activity
        viewTasksBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity on button click
                Intent i = new Intent(MainActivity.this,TasksActivity.class);
                startActivity(i);
            }
        });

    }
    private void addDataToFirestore(String taskName, String taskDate, String Card) {

        // creating a collection reference
        // for our Firebase Firestore database.
        CollectionReference dbTasks = db.collection("Courses");

        // adding our data to our courses object class.
        TasksC tasksC = new TasksC(taskName, taskDate, Card);

        // below method is use to add data to Firebase Firestore.
        dbTasks.add(tasksC).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                // after the data addition is successful
                // we are displaying a success toast message.
                Toast.makeText(MainActivity.this, "Your Course has been added to Firebase Firestore", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // this method is called when the data addition process is failed.
                // displaying a toast message when data addition is failed.
                Toast.makeText(MainActivity.this, "Fail to add course \n" + e, Toast.LENGTH_SHORT).show();
            }
        });
    }
}