package com.example.rfida;

public class TasksC {
    private String taskNumber, taskTime, taskDate;


    public TasksC() {
    }

    public TasksC(String taskNumber, String taskTime, String taskDate) {
        this.taskNumber = taskNumber;
        this.taskTime = taskTime;
        this.taskDate = taskDate;

    }

    public String getTaskNumber() {
        return taskNumber;
    }
    public String getTaskTime() {
        return taskTime;
    }
    public String getTaskDate() {
        return taskDate;
    }


}
